This spreasheet shows you the top gross movies between 2007 and 2011. Several missing or incorrect data have been fixed in line with related sources.

**Missing Data**:
"Leading Studio" for movie, No Reservations (2007), has been filled.
"Audience score" and "Rotten Tomatoes %" for movie, Something Borrowed (2011), have been filled. 

**Corrections**:
"Worldwide Gross" for movie, Tangled (2011), have been corrected.